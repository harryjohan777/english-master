package com.englishmaster.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF246BCE)
private val Ink = Color(0xFF18243A)
private val lessons = listOf(
    Lesson("Greetings", "अभिवादन", "Hello = नमस्ते", "How are you? = आप कैसे हैं?", "I am fine. = मैं ठीक हूँ।",
        listOf("What does “Hello” mean?", "Goodbye", "नमस्ते", "धन्यवाद"), 1),
    Lesson("Introducing yourself", "अपना परिचय देना", "My name is Rahul. = मेरा नाम राहुल है।",
        "I am from India. = मैं भारत से हूँ।", "Nice to meet you. = आपसे मिलकर अच्छा लगा।",
        listOf("Choose the correct meaning: “I am from India.”", "मैं भारत से हूँ।", "मैं ठीक हूँ।", "मेरा नाम भारत है।"), 1),
    Lesson("Everyday sentences", "रोज़मर्रा के वाक्य", "Please help me. = कृपया मेरी मदद करें।",
        "I don't understand. = मुझे समझ नहीं आया।", "Could you repeat that? = क्या आप इसे दोहरा सकते हैं?",
        listOf("“Please help me” का अर्थ क्या है?", "मुझे माफ़ करें", "कृपया मेरी मदद करें", "फिर मिलेंगे"), 2),
    Lesson("Simple present", "सामान्य वर्तमान काल", "I work every day. = मैं हर दिन काम करता/करती हूँ।",
        "She speaks English. = वह अंग्रेज़ी बोलती है।", "We learn together. = हम साथ में सीखते हैं।",
        listOf("Choose the correct sentence.", "She speak English.", "She speaks English.", "She speaking English."), 2),
    Lesson("At work", "काम की जगह पर", "I have a meeting. = मेरी एक मीटिंग है।",
        "I will send the email. = मैं ईमेल भेज दूँगा/दूँगी।", "Could you explain this? = क्या आप इसे समझा सकते हैं?",
        listOf("“Could you explain this?” is:", "एक विनम्र अनुरोध", "एक अभिवादन", "एक विदाई"), 1)
)
data class Lesson(val title: String, val hindi: String, val a: String, val b: String, val c: String,
                  val question: List<String>, val answer: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EnglishMasterApp() }
    }
}

@Composable
fun EnglishMasterApp() {
    var selected by remember { mutableIntStateOf(-1) }
    var completed by remember { mutableStateOf(setOf<Int>()) }
    var answer by remember { mutableIntStateOf(-1) }
    var showResult by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Color(0xFFF5F8FE))) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF5F8FE)) {
            if (selected >= 0) {
                LessonScreen(lessons[selected], answer, showResult,
                    onAnswer = { answer = it; showResult = true },
                    onBack = { selected = -1; answer = -1; showResult = false },
                    onNext = {
                        completed = completed + selected
                        selected = -1; answer = -1; showResult = false
                    })
            } else {
                HomeScreen(completed, onOpen = { selected = it })
            }
        }
    }
}

@Composable
fun HomeScreen(completed: Set<Int>, onOpen: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("ENGLISH MASTER", color = Blue, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            TeacherCard("नमस्ते! मैं आपका English Teacher हूँ। चलो आज English सीखते हैं!")
            Spacer(Modifier.height(8.dp))
            Text("नमस्ते! Let's learn English.", color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("हर दिन थोड़ा सीखें, आत्मविश्वास से बोलें।", color = Color.Gray, fontSize = 15.sp)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Blue), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("YOUR LEARNING JOURNEY", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                    Text("${completed.size} / ${lessons.size} lessons completed", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(progress = { completed.size.toFloat() / lessons.size },
                        modifier = Modifier.fillMaxWidth(), color = Color.White, trackColor = Color.White.copy(alpha = .25f))
                }
            }
        }
        item { Text("Choose a lesson  •  पाठ चुनें", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        items(lessons.size) { index ->
            val lesson = lessons[index]
            Card(modifier = Modifier.fillMaxWidth().clickable { onOpen(index) },
                colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Color(0xFFEAF2FF), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center) {
                        Text("${index + 1}", color = Blue, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(lesson.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(lesson.hindi, color = Color.Gray, fontSize = 14.sp)
                    }
                    Text(if (index in completed) "✓ Done" else "Start →",
                        color = if (index in completed) Color(0xFF16834A) else Blue, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item {
            Text("More practice coming soon: speaking, listening, vocabulary and advanced grammar.",
                color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
        }
    }
}

@Composable
fun LessonScreen(lesson: Lesson, answer: Int, showResult: Boolean,
                 onAnswer: (Int) -> Unit, onBack: () -> Unit, onNext: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("← Back", color = Blue, modifier = Modifier.clickable { onBack() }.padding(vertical = 8.dp))
        Spacer(Modifier.height(12.dp))
        Text(lesson.title, color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(lesson.hindi, color = Color.Gray, fontSize = 17.sp)
        Spacer(Modifier.height(20.dp))
        Text("Learn these sentences • ये वाक्य सीखें", color = Blue, fontWeight = FontWeight.Bold)
        listOf(lesson.a, lesson.b, lesson.c).forEachIndexed { i, line ->
            Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Text(line, Modifier.padding(16.dp), color = Ink, fontSize = 17.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("Quick quiz • छोटा टेस्ट", color = Ink, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(lesson.question[0], Modifier.padding(vertical = 12.dp), color = Ink)
        (1..3).forEach { option ->
            OutlinedButton(onClick = { if (!showResult) onAnswer(option) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = if (showResult && option == lesson.answer) Color(0xFFE2F7EA) else Color.White)) {
                Text("${'A' + option - 1}. ${lesson.question[option]}", color = Ink)
            }
        }
        if (showResult) {
            if (answer == lesson.answer) {
                TeacherCard("शाबाश! बिल्कुल सही जवाब! ऐसे ही मेहनत करते रहो। ⭐")
            } else {
                TeacherCard("अरे! ध्यान दो बेटा 😊 यह जवाब सही नहीं है। सही जवाब है: ${lesson.question[lesson.answer]} चलो, एक बार फिर समझते हैं!")
            }
            Button(onClick = onNext, modifier = Modifier.fillMaxWidth()) { Text("Finish lesson") }
        }
        Spacer(Modifier.weight(1f))
        Text("English Master • Learn at your own pace", color = Color.Gray, fontSize = 12.sp)
    }
}


@Composable
fun TeacherCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3D9)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("👨🏻‍🏫", fontSize = 42.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Master जी", color = Color(0xFF8A4B08), fontWeight = FontWeight.Bold)
                Text(message, color = Ink, fontSize = 14.sp)
            }
        }
    }
}
