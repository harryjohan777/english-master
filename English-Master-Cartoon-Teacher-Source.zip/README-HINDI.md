# English Master — Android starter app

यह शुरुआती Android ऐप है: हिंदी समझाइश, 5 sample lessons, छोटे quizzes, lesson completion progress और cartoon boy teacher (Master जी) के text reactions शामिल हैं।

## अभी क्या काम करता है
- Android पर lessons और quizzes
- सही जवाब पर तारीफ; गलत जवाब पर friendly teacher-style correction
- Lesson completion progress

## अभी क्या शामिल नहीं है
- असली AI chatbot / live voice conversation
- Microphone से pronunciation analysis
- Play Store publishing package / signed release
यह अगला development चरण है; इस ZIP को तैयार APK न समझें।

## APK बनाना
GitHub repository में इस project को upload करें। Actions tab में **Build English Master APK** workflow चलाएँ। सफल build के बाद workflow के Artifacts से `English-Master-debug-apk` डाउनलोड करें। Android में APK install करने के लिए browser/files app को install permission देनी पड़ सकती है।

Play Store के लिए बाद में signed Android App Bundle (AAB), privacy policy, store listing, testing और Google Play Developer account की जरूरत होगी।
